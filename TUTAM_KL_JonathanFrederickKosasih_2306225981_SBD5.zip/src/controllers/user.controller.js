const userRepository = require('../repositories/user.repository');
const baseResponse = require("../utils/baseResponse.util");

exports.registerUser = async (req, res) => {
    if (!req.query.name || !req.query.email || !req.query.password) {
        return baseResponse(res, false, 400, "Missing user name, email, or password", null);
    }
    try {
        if (await userRepository.getUserByEmail(req.query.email)) {
            return baseResponse(res, false, 400, "Email already registered", null);
        }
        const user = await userRepository.registerUser(req.query);
        baseResponse(res, true, 201, "User created", user);
    } catch (error) {
        baseResponse(res, false, 500, error.message || "Server error", error);
    }
}

exports.loginUser = async (req, res) => {
    if (!req.query.email || !req.query.password) {
        return baseResponse(res, false, 400, "Missing email or password", null);
    }
    try {
        const user = await userRepository.loginUser(req.query.email, req.query.password);
        if (user === null) {
            return baseResponse(res, false, 404, "Invalid email or password", null);
        }
        baseResponse(res, true, 200, "Login success", user);
    } catch (error) {
        baseResponse(res, false, 500, "Error retrieving user", error);
    }
}

exports.getUserByEmail = async (req, res) => {
    try {
        const user = await userRepository.getUserByEmail(req.params.email);
        if (!user) {
            return baseResponse(res, false, 404, "User not found", null);
        }
        baseResponse(res, true, 200, "User found", user);
    } catch (error) {
        baseResponse(res, false, 500, "Error retrieving user", error);
    }
}

exports.updateUser = async (req, res) => {
    if (!req.body.name || !req.body.email || !req.body.password) {
        return baseResponse(res, false, 400, "Missing user name, email, or password", null);
    }
    try {
        const user = await userRepository.updateUser(req.body);
        if (!user) {
            return baseResponse(res, false, 404, "User not found", null);
        }
        baseResponse(res, true, 200, "User updated", user);
    } catch (error) {
        baseResponse(res, false, 500, "Error updating user", error);
    }
}

exports.deleteUser = async (req, res) => {
    try {
        const deleted = await userRepository.deleteUser(req.params.id);
        if (!deleted) {
            return baseResponse(res, false, 404, "User not found", null);
        }
        baseResponse(res, true, 200, "User deleted", deleted);
    } catch (error) {
        baseResponse(res, false, 500, "Error deleting user", error);
    }
}