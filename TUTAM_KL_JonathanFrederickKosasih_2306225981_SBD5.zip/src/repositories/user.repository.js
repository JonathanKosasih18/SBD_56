const db = require("../database/pg.database");

exports.registerUser = async (user) => {
    try {
        const result = await db.query(
            "INSERT INTO users(name, email, password, balance) VALUES($1, $2, $3, 0) RETURNING *",
            [user.name, user.email, user.password]
        );
        return result.rows[0];
    } catch (error) {
        console.error("User repository error", error);
    }
};

exports.loginUser = async (email, password) => {
    try {
        const result = await db.query("SELECT * FROM users WHERE email = $1 AND password = $2", [email, password]);
        if(result.rows.length === 0) {
            return null;
        }
        return result.rows[0];
    } catch (error) {
        console.error("User repository error", error);
    }
}

exports.getUserByEmail = async (email) => {
    try {
        const result = await db.query("SELECT * FROM users WHERE email = $1", [email]);
        return result.rows[0];
    } catch (error) {
        console.error("User repository error", error);
    }
}

exports.updateUser = async (user) => {
    try {
        const result = await db.query(
            "UPDATE users SET name = $1, email = $2, password = $3 WHERE id = $4 RETURNING *",
            [user.name, user.email, user.password, user.id]
        );
        return result.rows[0];
    } catch (error) {
        console.error("User repository error", error);
    }
}

exports.deleteUser = async (id) => {
    try {
        const result = await db.query("DELETE FROM users WHERE id = $1 RETURNING *", [id]);
        return result.rows[0];
    } catch (error) {
        console.error("User repository error", error);
    }
}