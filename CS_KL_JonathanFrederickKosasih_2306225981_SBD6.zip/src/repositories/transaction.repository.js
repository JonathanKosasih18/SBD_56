const db = require("../database/pg.database");

exports.createTransaction = async (transaction) => {
    try {
        const result = await db.query(
            "INSERT INTO transactions(user_id, item_id, quantity, total) VALUES($1, $2, $3, $4) RETURNING *",
            [transaction.user_id, transaction.item_id, transaction.quantity, transaction.total]
        );
        return result.rows[0];
    } catch (error) {
        console.error("Transaction repository error", error);
    }
}

exports.getTransactionById = async (id) => {
    try {
        const result = await db.query("SELECT * FROM transactions WHERE id = $1", 
            [id]
        );
        return result.rows[0];
    } catch (error) {
        console.error("Transaction repository error", error);
    }
}

exports.handlePayment = async (id) => {
    try {
        const result = await db.query("UPDATE transactions SET status = 'paid' WHERE id = $1 RETURNING *", 
            [id]
        );
        return result.rows[0];
    } catch (error) {
        console.error("Transaction repository error", error);
    }
}

exports.deleteTransaction = async (id) => {
    try {
        const result = await db.query("DELETE FROM transactions WHERE id = $1 RETURNING *", 
            [id]
        );
        return result.rows[0];
    } catch (error) {
        console.error("Transaction repository error", error);
    }
}
