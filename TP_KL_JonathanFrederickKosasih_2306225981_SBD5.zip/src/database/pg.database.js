require("dotenv").config();

const { Pool } = require("pg");

const pool = new Pool({
    connectionString: process.env.PG_CONNECTION_STRING,
    ssl: {
        rejectUnauthorized: false
    } 
});

const connect = async () => {
    try {
        await pool.connect();
        console.log("Database connected!");
    } catch (error) {
        console.error("Database connection error", error);
    }
}

connect();

const query = async (text, params) => {
    try {
        const result = await pool.query(text, params);
        return result;
    } catch (error) {
        console.error("Database query error", error);
    }
}
module.exports = { query };